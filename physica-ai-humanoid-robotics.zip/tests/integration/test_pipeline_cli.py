"""
CLI integration tests for the pipeline verification system.

This module tests the CLI interface integration with all pipeline components.
"""
import unittest
import tempfile
import os
from io import StringIO
from unittest.mock import patch, MagicMock

from src.cli.pipeline_cli import create_pipeline_parser, handle_start_command, handle_status_command, handle_resume_command
from src.pipeline.state_persistence import StatePersistence
from src.pipeline.state_machine import PipelineState


class TestPipelineCLIIntegration(unittest.TestCase):
    """
    CLI integration tests for pipeline verification system.
    """
    def setUp(self):
        """
        Set up test fixtures before each test method.
        """
        # Create a temporary file for testing
        self.temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.json')
        self.temp_file.close()

    def tearDown(self):
        """
        Clean up after each test method.
        """
        # Remove the temporary file if it exists
        if os.path.exists(self.temp_file.name):
            os.remove(self.temp_file.name)

    def test_cli_parser_creation(self):
        """
        Test that the CLI parser is created with all required commands.
        """
        parser = create_pipeline_parser()

        # Test that parser has the required commands
        self.assertIsNotNone(parser)

        # Test that the main commands exist
        subparsers_actions = [
            action for action in parser._actions
            if isinstance(action, type(parser._subparsers._group_actions[0]))
        ]

        if subparsers_actions:
            subparser_choices = list(subparsers_actions[0].choices.keys())
            self.assertIn("start", subparser_choices)
            self.assertIn("status", subparser_choices)
            self.assertIn("resume", subparser_choices)
            self.assertIn("validate", subparser_choices)

    def test_start_command_handler(self):
        """
        Test the start command handler.
        """
        # Create mock args
        class MockArgs:
            state_file = self.temp_file.name
            config = None
            dry_run = False
            command = "start"

        mock_args = MockArgs()

        # Test the start command handler
        result = handle_start_command(mock_args)

        # Result should be 0 for success or non-zero for failure
        # In this case, it should succeed in initializing the pipeline
        self.assertIsInstance(result, int)

    def test_status_command_handler(self):
        """
        Test the status command handler.
        """
        # First initialize a state file
        state_persistence = StatePersistence(self.temp_file.name)
        state_persistence.update_state(PipelineState.EXTRACTION_IN_PROGRESS)

        # Create mock args
        class MockArgs:
            state_file = self.temp_file.name
            command = "status"

        mock_args = MockArgs()

        # Test the status command handler
        result = handle_status_command(mock_args)

        # Result should be 0 for success
        self.assertIsInstance(result, int)

    def test_resume_command_handler(self):
        """
        Test the resume command handler.
        """
        # First initialize a state file
        state_persistence = StatePersistence(self.temp_file.name)
        state_persistence.update_state(PipelineState.FAILED)

        # Create mock args
        class MockArgs:
            state_file = self.temp_file.name
            force_extraction = False
            force_chunking = False
            command = "resume"

        mock_args = MockArgs()

        # Test the resume command handler
        result = handle_resume_command(mock_args)

        # Result should be 0 for success or non-zero for failure
        self.assertIsInstance(result, int)

    def test_start_command_with_config(self):
        """
        Test the start command handler with a configuration file.
        """
        # Create a temporary config file
        temp_config = tempfile.NamedTemporaryFile(delete=False, suffix='.json')
        temp_config.write(b'{"input_path": "/test/path", "output_path": "/test/output"}')
        temp_config.close()

        try:
            # Create mock args
            class MockArgs:
                state_file = self.temp_file.name
                config = temp_config.name
                dry_run = False
                command = "start"

            mock_args = MockArgs()

            # Test the start command handler with config
            result = handle_start_command(mock_args)

            # Result should be 0 for success or non-zero for failure
            self.assertIsInstance(result, int)
        finally:
            # Clean up the temp config file
            if os.path.exists(temp_config.name):
                os.remove(temp_config.name)

    def test_dry_run_mode_handling(self):
        """
        Test the start command handler in dry-run mode.
        """
        # Create mock args with dry-run enabled
        class MockArgs:
            state_file = self.temp_file.name
            config = None
            dry_run = True
            command = "start"

        mock_args = MockArgs()

        # Test the start command handler in dry-run mode
        result = handle_start_command(mock_args)

        # Result should be 0 for success
        self.assertIsInstance(result, int)

    @patch('sys.stdout', new_callable=StringIO)
    def test_status_command_output(self, mock_stdout):
        """
        Test the status command output.
        """
        # First initialize a state file with some data
        state_persistence = StatePersistence(self.temp_file.name)
        state_data = {
            "state": PipelineState.EXTRACTION_COMPLETE.value,
            "timestamp": "2025-12-23T10:00:00Z",
            "approvals": {
                "extraction": {
                    "status": "PENDING",
                    "approver": "test_user",
                    "decision": "PENDING"
                }
            },
            "artifact_paths": {
                "extracted_content": "/path/to/content.txt",
                "chunked_output": "/path/to/chunks.json"
            }
        }
        state_persistence.write_state(state_data)

        # Create mock args
        class MockArgs:
            state_file = self.temp_file.name
            command = "status"

        mock_args = MockArgs()

        # Test the status command handler
        result = handle_status_command(mock_args)

        # Check that output was generated
        output = mock_stdout.getvalue()
        self.assertIsInstance(result, int)
        self.assertIn("EXTRACTION_COMPLETE", output)


if __name__ == '__main__':
    unittest.main()