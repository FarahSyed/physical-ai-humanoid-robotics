"""
Unit tests for the state persistence module.
"""
import os
import tempfile
import unittest
from pathlib import Path

from src.pipeline.state_machine import PipelineState
from src.pipeline.state_persistence import StatePersistence


class TestStatePersistence(unittest.TestCase):
    """
    Test cases for StatePersistence class.
    """
    def setUp(self):
        """
        Set up test fixtures before each test method.
        """
        # Create a temporary file for testing
        self.temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.json')
        self.temp_file.close()
        self.state_persistence = StatePersistence(self.temp_file.name)

    def tearDown(self):
        """
        Clean up after each test method.
        """
        # Remove the temporary file
        if os.path.exists(self.temp_file.name):
            os.remove(self.temp_file.name)

    def test_initial_state_read(self):
        """
        Test reading initial state when file doesn't exist.
        """
        # State file doesn't exist initially, so read_state should return None
        state_data = self.state_persistence.read_state()
        self.assertIsNone(state_data)

    def test_write_and_read_state(self):
        """
        Test writing and reading state.
        """
        test_state = {
            "state": PipelineState.EXTRACTION_IN_PROGRESS.value,
            "timestamp": "2025-12-23T10:00:00Z"
        }

        # Write state
        success = self.state_persistence.write_state(test_state)
        self.assertTrue(success)

        # Read state back
        read_state = self.state_persistence.read_state()
        self.assertIsNotNone(read_state)
        self.assertEqual(read_state["state"], PipelineState.EXTRACTION_IN_PROGRESS.value)

    def test_update_state_valid_transition(self):
        """
        Test updating state with valid transition.
        """
        # Start with IDLE
        result = self.state_persistence.update_state(PipelineState.IDLE)
        self.assertTrue(result)

        # Transition to EXTRACTION_IN_PROGRESS (valid transition)
        result = self.state_persistence.update_state(PipelineState.EXTRACTION_IN_PROGRESS)
        self.assertTrue(result)

        # Check that the state was updated
        current_state = self.state_persistence.get_current_state()
        self.assertEqual(current_state, PipelineState.EXTRACTION_IN_PROGRESS)

    def test_update_state_invalid_transition(self):
        """
        Test updating state with invalid transition.
        """
        # Start with IDLE
        result = self.state_persistence.update_state(PipelineState.IDLE)
        self.assertTrue(result)

        # Try to transition directly to CHUNKING_IN_PROGRESS (invalid transition)
        result = self.state_persistence.update_state(PipelineState.CHUNKING_IN_PROGRESS)
        self.assertFalse(result)

    def test_get_current_state(self):
        """
        Test getting current state.
        """
        # Write a test state
        test_state = {
            "state": PipelineState.EXTRACTION_COMPLETE.value,
            "timestamp": "2025-12-23T10:00:00Z"
        }
        self.state_persistence.write_state(test_state)

        # Get current state
        current_state = self.state_persistence.get_current_state()
        self.assertEqual(current_state, PipelineState.EXTRACTION_COMPLETE)

    def test_check_state_corruption_valid(self):
        """
        Test checking state corruption with valid state.
        """
        test_state = {
            "state": PipelineState.IDLE.value,
            "timestamp": "2025-12-23T10:00:00Z"
        }
        self.state_persistence.write_state(test_state)

        is_valid = self.state_persistence.check_state_corruption()
        self.assertTrue(is_valid)

    def test_validate_artifact_consistency(self):
        """
        Test validating artifact consistency.
        """
        # Create temporary files for testing
        with tempfile.NamedTemporaryFile(delete=False) as temp1:
            temp1.write(b"test content")
            temp1_path = temp1.name

        try:
            # Write state with artifact paths
            test_state = {
                "state": PipelineState.EXTRACTION_COMPLETE.value,
                "timestamp": "2025-12-23T10:00:00Z",
                "artifact_paths": {
                    "extracted_content": temp1_path,
                    "chunked_output": "nonexistent_file.txt"
                }
            }
            self.state_persistence.write_state(test_state)

            # Validate consistency - should return False because one file doesn't exist
            is_consistent = self.state_persistence.validate_artifact_consistency()
            self.assertFalse(is_consistent)

            # Test with existing file only
            with tempfile.NamedTemporaryFile(delete=False) as temp2:
                temp2.write(b"test content")
                temp2_path = temp2.name

            try:
                test_state["artifact_paths"] = {
                    "extracted_content": temp1_path,
                    "chunked_output": temp2_path
                }
                self.state_persistence.write_state(test_state)

                is_consistent = self.state_persistence.validate_artifact_consistency()
                self.assertTrue(is_consistent)
            finally:
                os.remove(temp2_path)
        finally:
            os.remove(temp1_path)

    def test_reset_state(self):
        """
        Test resetting state to IDLE.
        """
        # Write a test state
        test_state = {
            "state": PipelineState.EXTRACTION_COMPLETE.value,
            "timestamp": "2025-12-23T10:00:00Z"
        }
        self.state_persistence.write_state(test_state)

        # Reset state
        result = self.state_persistence.reset_state()
        self.assertTrue(result)

        # Check that state is now IDLE
        current_state = self.state_persistence.get_current_state()
        self.assertEqual(current_state, PipelineState.IDLE)


if __name__ == '__main__':
    unittest.main()