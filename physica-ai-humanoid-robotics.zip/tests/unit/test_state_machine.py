"""
Unit tests for the state machine module.
"""
import unittest
from src.pipeline.state_machine import PipelineState, StateTransitionValidator, validate_state_transition


class TestStateMachine(unittest.TestCase):
    """
    Test cases for state machine functionality.
    """

    def test_pipeline_state_enum_values(self):
        """
        Test that PipelineState enum has all expected values.
        """
        expected_states = {
            "IDLE", "EXTRACTION_IN_PROGRESS", "EXTRACTION_COMPLETE", "EXTRACTION_APPROVED",
            "CHUNKING_IN_PROGRESS", "CHUNKING_COMPLETE", "CHUNKING_APPROVED",
            "EMBEDDING_IN_PROGRESS", "EMBEDDING_COMPLETE", "FAILED", "REJECTED"
        }

        actual_states = {state.value for state in PipelineState}
        self.assertEqual(actual_states, expected_states)

    def test_state_transition_validator_valid_transitions(self):
        """
        Test that valid state transitions are allowed.
        """
        # Test transitions from IDLE
        self.assertTrue(StateTransitionValidator.is_valid_transition(
            PipelineState.IDLE, PipelineState.EXTRACTION_IN_PROGRESS))

        # Test transitions from EXTRACTION_IN_PROGRESS
        self.assertTrue(StateTransitionValidator.is_valid_transition(
            PipelineState.EXTRACTION_IN_PROGRESS, PipelineState.EXTRACTION_COMPLETE))
        self.assertTrue(StateTransitionValidator.is_valid_transition(
            PipelineState.EXTRACTION_IN_PROGRESS, PipelineState.FAILED))

        # Test transitions from EXTRACTION_COMPLETE
        self.assertTrue(StateTransitionValidator.is_valid_transition(
            PipelineState.EXTRACTION_COMPLETE, PipelineState.EXTRACTION_APPROVED))
        self.assertTrue(StateTransitionValidator.is_valid_transition(
            PipelineState.EXTRACTION_COMPLETE, PipelineState.REJECTED))

        # Test transitions from EXTRACTION_APPROVED
        self.assertTrue(StateTransitionValidator.is_valid_transition(
            PipelineState.EXTRACTION_APPROVED, PipelineState.CHUNKING_IN_PROGRESS))

        # Test transitions from CHUNKING_IN_PROGRESS
        self.assertTrue(StateTransitionValidator.is_valid_transition(
            PipelineState.CHUNKING_IN_PROGRESS, PipelineState.CHUNKING_COMPLETE))
        self.assertTrue(StateTransitionValidator.is_valid_transition(
            PipelineState.CHUNKING_IN_PROGRESS, PipelineState.FAILED))

        # Test transitions from CHUNKING_COMPLETE
        self.assertTrue(StateTransitionValidator.is_valid_transition(
            PipelineState.CHUNKING_COMPLETE, PipelineState.CHUNKING_APPROVED))
        self.assertTrue(StateTransitionValidator.is_valid_transition(
            PipelineState.CHUNKING_COMPLETE, PipelineState.REJECTED))

        # Test transitions from CHUNKING_APPROVED
        self.assertTrue(StateTransitionValidator.is_valid_transition(
            PipelineState.CHUNKING_APPROVED, PipelineState.EMBEDDING_IN_PROGRESS))

        # Test transitions from EMBEDDING_IN_PROGRESS
        self.assertTrue(StateTransitionValidator.is_valid_transition(
            PipelineState.EMBEDDING_IN_PROGRESS, PipelineState.EMBEDDING_COMPLETE))
        self.assertTrue(StateTransitionValidator.is_valid_transition(
            PipelineState.EMBEDDING_IN_PROGRESS, PipelineState.FAILED))

        # Test transitions from FAILED
        self.assertTrue(StateTransitionValidator.is_valid_transition(
            PipelineState.FAILED, PipelineState.IDLE))

    def test_state_transition_validator_invalid_transitions(self):
        """
        Test that invalid state transitions are rejected.
        """
        # Test invalid transitions from IDLE
        self.assertFalse(StateTransitionValidator.is_valid_transition(
            PipelineState.IDLE, PipelineState.EXTRACTION_COMPLETE))  # Skip in-progress
        self.assertFalse(StateTransitionValidator.is_valid_transition(
            PipelineState.IDLE, PipelineState.FAILED))

        # Test invalid transitions from EXTRACTION_COMPLETE
        self.assertFalse(StateTransitionValidator.is_valid_transition(
            PipelineState.EXTRACTION_COMPLETE, PipelineState.CHUNKING_IN_PROGRESS))  # Skip approval

        # Test invalid transitions (self-transitions)
        for state in PipelineState:
            self.assertFalse(StateTransitionValidator.is_valid_transition(state, state))

    def test_get_valid_next_states(self):
        """
        Test getting valid next states for each state.
        """
        # Check valid next states for IDLE
        valid_next = StateTransitionValidator.get_valid_next_states(PipelineState.IDLE)
        expected = {PipelineState.EXTRACTION_IN_PROGRESS}
        self.assertEqual(valid_next, expected)

        # Check valid next states for EXTRACTION_IN_PROGRESS
        valid_next = StateTransitionValidator.get_valid_next_states(PipelineState.EXTRACTION_IN_PROGRESS)
        expected = {PipelineState.EXTRACTION_COMPLETE, PipelineState.FAILED}
        self.assertEqual(valid_next, expected)

        # Check valid next states for FAILED
        valid_next = StateTransitionValidator.get_valid_next_states(PipelineState.FAILED)
        expected = {PipelineState.IDLE}
        self.assertEqual(valid_next, expected)

    def test_is_terminal_state(self):
        """
        Test identifying terminal states.
        """
        # EMBEDDING_COMPLETE should be terminal (no further transitions)
        self.assertTrue(StateTransitionValidator.is_terminal_state(PipelineState.EMBEDDING_COMPLETE))

        # REJECTED should be terminal (no further transitions)
        self.assertTrue(StateTransitionValidator.is_terminal_state(PipelineState.REJECTED))

        # IDLE should not be terminal (has transitions)
        self.assertFalse(StateTransitionValidator.is_terminal_state(PipelineState.IDLE))

        # EXTRACTION_IN_PROGRESS should not be terminal (has transitions)
        self.assertFalse(StateTransitionValidator.is_terminal_state(PipelineState.EXTRACTION_IN_PROGRESS))

    def test_validate_state_transition_function(self):
        """
        Test the public validate_state_transition function.
        """
        # Valid transition
        self.assertTrue(validate_state_transition(
            PipelineState.IDLE, PipelineState.EXTRACTION_IN_PROGRESS))

        # Invalid transition
        self.assertFalse(validate_state_transition(
            PipelineState.IDLE, PipelineState.EXTRACTION_COMPLETE))

        # Self transition (invalid)
        self.assertFalse(validate_state_transition(
            PipelineState.IDLE, PipelineState.IDLE))


if __name__ == '__main__':
    unittest.main()