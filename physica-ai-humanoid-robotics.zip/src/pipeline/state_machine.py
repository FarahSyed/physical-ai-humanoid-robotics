"""
Pipeline state machine implementation for the verification system.

This module defines the PipelineState enum and state transition validation logic
for the human approval gates and persisted state control system.
"""
from enum import Enum
from typing import Set, Dict, Tuple


class PipelineState(Enum):
    """
    Enum representing the current state of the pipeline with allowed values:
    IDLE, EXTRACTION_IN_PROGRESS, EXTRACTION_COMPLETE, EXTRACTION_APPROVED,
    CHUNKING_IN_PROGRESS, CHUNKING_COMPLETE, CHUNKING_APPROVED,
    EMBEDDING_IN_PROGRESS, EMBEDDING_COMPLETE, FAILED, REJECTED
    """
    IDLE = "IDLE"
    EXTRACTION_IN_PROGRESS = "EXTRACTION_IN_PROGRESS"
    EXTRACTION_COMPLETE = "EXTRACTION_COMPLETE"
    EXTRACTION_APPROVED = "EXTRACTION_APPROVED"
    CHUNKING_IN_PROGRESS = "CHUNKING_IN_PROGRESS"
    CHUNKING_COMPLETE = "CHUNKING_COMPLETE"
    CHUNKING_APPROVED = "CHUNKING_APPROVED"
    EMBEDDING_IN_PROGRESS = "EMBEDDING_IN_PROGRESS"
    EMBEDDING_COMPLETE = "EMBEDDING_COMPLETE"
    FAILED = "FAILED"
    REJECTED = "REJECTED"


class StateTransitionValidator:
    """
    Validates state transitions according to the defined rules:
    IDLE→EXTRACTION_IN_PROGRESS→EXTRACTION_COMPLETE→EXTRACTION_APPROVED→
    CHUNKING_IN_PROGRESS→CHUNKING_COMPLETE→CHUNKING_APPROVED→
    EMBEDDING_IN_PROGRESS→EMBEDDING_COMPLETE,
    EXTRACTION_COMPLETE→REJECTED, CHUNKING_COMPLETE→REJECTED,
    any_state→FAILED (on system error)
    """

    # Define valid state transitions
    VALID_TRANSITIONS: Dict[PipelineState, Set[PipelineState]] = {
        PipelineState.IDLE: {PipelineState.EXTRACTION_IN_PROGRESS},
        PipelineState.EXTRACTION_IN_PROGRESS: {PipelineState.EXTRACTION_COMPLETE, PipelineState.FAILED},
        PipelineState.EXTRACTION_COMPLETE: {PipelineState.EXTRACTION_APPROVED, PipelineState.REJECTED},
        PipelineState.EXTRACTION_APPROVED: {PipelineState.CHUNKING_IN_PROGRESS},
        PipelineState.CHUNKING_IN_PROGRESS: {PipelineState.CHUNKING_COMPLETE, PipelineState.FAILED},
        PipelineState.CHUNKING_COMPLETE: {PipelineState.CHUNKING_APPROVED, PipelineState.REJECTED},
        PipelineState.CHUNKING_APPROVED: {PipelineState.EMBEDDING_IN_PROGRESS},
        PipelineState.EMBEDDING_IN_PROGRESS: {PipelineState.EMBEDDING_COMPLETE, PipelineState.FAILED},
        PipelineState.EMBEDDING_COMPLETE: set(),  # Terminal state
        PipelineState.FAILED: {PipelineState.IDLE},  # Can restart from failure
        PipelineState.REJECTED: set()  # Terminal state for rejected pipelines
    }

    @classmethod
    def is_valid_transition(cls, from_state: PipelineState, to_state: PipelineState) -> bool:
        """
        Check if a state transition is valid.

        Args:
            from_state: The current state
            to_state: The target state

        Returns:
            True if the transition is valid, False otherwise
        """
        return to_state in cls.VALID_TRANSITIONS.get(from_state, set())

    @classmethod
    def get_valid_next_states(cls, current_state: PipelineState) -> Set[PipelineState]:
        """
        Get all valid next states for the current state.

        Args:
            current_state: The current pipeline state

        Returns:
            Set of valid next states
        """
        return cls.VALID_TRANSITIONS.get(current_state, set())

    @classmethod
    def is_terminal_state(cls, state: PipelineState) -> bool:
        """
        Check if a state is terminal (no further transitions allowed).

        Args:
            state: The pipeline state to check

        Returns:
            True if the state is terminal, False otherwise
        """
        return len(cls.VALID_TRANSITIONS.get(state, set())) == 0


def validate_state_transition(from_state: PipelineState, to_state: PipelineState) -> bool:
    """
    Public function to validate state transitions.

    Args:
        from_state: The current state
        to_state: The target state

    Returns:
        True if the transition is valid, False otherwise
    """
    return StateTransitionValidator.is_valid_transition(from_state, to_state)


# Alias for backward compatibility
StateTransitionValidator = StateTransitionValidator