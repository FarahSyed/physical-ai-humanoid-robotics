export default [
  require("C:\\Users\\Noman Traders\\Desktop\\Hackathon\\physical-ai-humanoid-robotics\\frontend\\node_modules\\infima\\dist\\css\\default\\default.css"),
  require("C:\\Users\\Noman Traders\\Desktop\\Hackathon\\physical-ai-humanoid-robotics\\frontend\\node_modules\\@docusaurus\\theme-classic\\lib\\prism-include-languages"),
  require("C:\\Users\\Noman Traders\\Desktop\\Hackathon\\physical-ai-humanoid-robotics\\frontend\\node_modules\\@docusaurus\\theme-classic\\lib\\nprogress"),
  require("C:\\Users\\Noman Traders\\Desktop\\Hackathon\\physical-ai-humanoid-robotics\\frontend\\src\\css\\custom.css"),
];
