import React from 'react';
import ComponentCreator from '@docusaurus/ComponentCreator';

export default [
  {
    path: '/physical-ai-humanoid-robotics/__docusaurus/debug',
    component: ComponentCreator('/physical-ai-humanoid-robotics/__docusaurus/debug', 'a7d'),
    exact: true
  },
  {
    path: '/physical-ai-humanoid-robotics/__docusaurus/debug/config',
    component: ComponentCreator('/physical-ai-humanoid-robotics/__docusaurus/debug/config', '542'),
    exact: true
  },
  {
    path: '/physical-ai-humanoid-robotics/__docusaurus/debug/content',
    component: ComponentCreator('/physical-ai-humanoid-robotics/__docusaurus/debug/content', 'e1e'),
    exact: true
  },
  {
    path: '/physical-ai-humanoid-robotics/__docusaurus/debug/globalData',
    component: ComponentCreator('/physical-ai-humanoid-robotics/__docusaurus/debug/globalData', 'ade'),
    exact: true
  },
  {
    path: '/physical-ai-humanoid-robotics/__docusaurus/debug/metadata',
    component: ComponentCreator('/physical-ai-humanoid-robotics/__docusaurus/debug/metadata', '3e3'),
    exact: true
  },
  {
    path: '/physical-ai-humanoid-robotics/__docusaurus/debug/registry',
    component: ComponentCreator('/physical-ai-humanoid-robotics/__docusaurus/debug/registry', 'a96'),
    exact: true
  },
  {
    path: '/physical-ai-humanoid-robotics/__docusaurus/debug/routes',
    component: ComponentCreator('/physical-ai-humanoid-robotics/__docusaurus/debug/routes', 'b0c'),
    exact: true
  },
  {
    path: '/physical-ai-humanoid-robotics/docs',
    component: ComponentCreator('/physical-ai-humanoid-robotics/docs', 'f21'),
    routes: [
      {
        path: '/physical-ai-humanoid-robotics/docs',
        component: ComponentCreator('/physical-ai-humanoid-robotics/docs', '136'),
        routes: [
          {
            path: '/physical-ai-humanoid-robotics/docs',
            component: ComponentCreator('/physical-ai-humanoid-robotics/docs', 'ef5'),
            routes: [
              {
                path: '/physical-ai-humanoid-robotics/docs/communication-patterns-integration',
                component: ComponentCreator('/physical-ai-humanoid-robotics/docs/communication-patterns-integration', 'fa0'),
                exact: true
              },
              {
                path: '/physical-ai-humanoid-robotics/docs/cross-chapter-consistency-review',
                component: ComponentCreator('/physical-ai-humanoid-robotics/docs/cross-chapter-consistency-review', '05c'),
                exact: true
              },
              {
                path: '/physical-ai-humanoid-robotics/docs/end-to-end-humanoid-system-integration',
                component: ComponentCreator('/physical-ai-humanoid-robotics/docs/end-to-end-humanoid-system-integration', '993'),
                exact: true
              },
              {
                path: '/physical-ai-humanoid-robotics/docs/intro/about-this-book',
                component: ComponentCreator('/physical-ai-humanoid-robotics/docs/intro/about-this-book', '64d'),
                exact: true,
                sidebar: "introSidebar"
              },
              {
                path: '/physical-ai-humanoid-robotics/docs/intro/next-steps',
                component: ComponentCreator('/physical-ai-humanoid-robotics/docs/intro/next-steps', 'b47'),
                exact: true,
                sidebar: "introSidebar"
              },
              {
                path: '/physical-ai-humanoid-robotics/docs/intro/prerequisites',
                component: ComponentCreator('/physical-ai-humanoid-robotics/docs/intro/prerequisites', '615'),
                exact: true,
                sidebar: "introSidebar"
              },
              {
                path: '/physical-ai-humanoid-robotics/docs/intro/timeline',
                component: ComponentCreator('/physical-ai-humanoid-robotics/docs/intro/timeline', '4c0'),
                exact: true,
                sidebar: "introSidebar"
              },
              {
                path: '/physical-ai-humanoid-robotics/docs/intro/welcome',
                component: ComponentCreator('/physical-ai-humanoid-robotics/docs/intro/welcome', 'f7f'),
                exact: true,
                sidebar: "introSidebar"
              },
              {
                path: '/physical-ai-humanoid-robotics/docs/week1-2-intro/humanoid-robotics-landscape',
                component: ComponentCreator('/physical-ai-humanoid-robotics/docs/week1-2-intro/humanoid-robotics-landscape', '7fe'),
                exact: true,
                sidebar: "introSidebar"
              },
              {
                path: '/physical-ai-humanoid-robotics/docs/week1-2-intro/physical-ai-foundations',
                component: ComponentCreator('/physical-ai-humanoid-robotics/docs/week1-2-intro/physical-ai-foundations', 'ec5'),
                exact: true,
                sidebar: "introSidebar"
              },
              {
                path: '/physical-ai-humanoid-robotics/docs/week1-2-intro/sensor-systems',
                component: ComponentCreator('/physical-ai-humanoid-robotics/docs/week1-2-intro/sensor-systems', '44e'),
                exact: true,
                sidebar: "introSidebar"
              },
              {
                path: '/physical-ai-humanoid-robotics/docs/week11-12-humanoid/',
                component: ComponentCreator('/physical-ai-humanoid-robotics/docs/week11-12-humanoid/', 'eea'),
                exact: true,
                sidebar: "introSidebar"
              },
              {
                path: '/physical-ai-humanoid-robotics/docs/week11-12-humanoid/chapter-1-kinematics-dynamics',
                component: ComponentCreator('/physical-ai-humanoid-robotics/docs/week11-12-humanoid/chapter-1-kinematics-dynamics', '315'),
                exact: true,
                sidebar: "introSidebar"
              },
              {
                path: '/physical-ai-humanoid-robotics/docs/week11-12-humanoid/chapter-2-locomotion-balance-control',
                component: ComponentCreator('/physical-ai-humanoid-robotics/docs/week11-12-humanoid/chapter-2-locomotion-balance-control', '560'),
                exact: true,
                sidebar: "introSidebar"
              },
              {
                path: '/physical-ai-humanoid-robotics/docs/week11-12-humanoid/chapter-3-manipulation-grasping',
                component: ComponentCreator('/physical-ai-humanoid-robotics/docs/week11-12-humanoid/chapter-3-manipulation-grasping', '04a'),
                exact: true,
                sidebar: "introSidebar"
              },
              {
                path: '/physical-ai-humanoid-robotics/docs/week11-12-humanoid/chapter-4-human-robot-interaction',
                component: ComponentCreator('/physical-ai-humanoid-robotics/docs/week11-12-humanoid/chapter-4-human-robot-interaction', '38a'),
                exact: true,
                sidebar: "introSidebar"
              },
              {
                path: '/physical-ai-humanoid-robotics/docs/week11-12-humanoid/glossary',
                component: ComponentCreator('/physical-ai-humanoid-robotics/docs/week11-12-humanoid/glossary', 'e1d'),
                exact: true
              },
              {
                path: '/physical-ai-humanoid-robotics/docs/week13-conversational-robotics/chapter-1-conversational-ai',
                component: ComponentCreator('/physical-ai-humanoid-robotics/docs/week13-conversational-robotics/chapter-1-conversational-ai', '495'),
                exact: true,
                sidebar: "introSidebar"
              },
              {
                path: '/physical-ai-humanoid-robotics/docs/week13-conversational-robotics/chapter-2-implementation-integration',
                component: ComponentCreator('/physical-ai-humanoid-robotics/docs/week13-conversational-robotics/chapter-2-implementation-integration', 'a95'),
                exact: true,
                sidebar: "introSidebar"
              },
              {
                path: '/physical-ai-humanoid-robotics/docs/week13-conversational-robotics/glossary',
                component: ComponentCreator('/physical-ai-humanoid-robotics/docs/week13-conversational-robotics/glossary', '253'),
                exact: true,
                sidebar: "introSidebar"
              },
              {
                path: '/physical-ai-humanoid-robotics/docs/week13-conversational-robotics/resources',
                component: ComponentCreator('/physical-ai-humanoid-robotics/docs/week13-conversational-robotics/resources', '267'),
                exact: true,
                sidebar: "introSidebar"
              },
              {
                path: '/physical-ai-humanoid-robotics/docs/week3-5-ros2/',
                component: ComponentCreator('/physical-ai-humanoid-robotics/docs/week3-5-ros2/', '634'),
                exact: true,
                sidebar: "introSidebar"
              },
              {
                path: '/physical-ai-humanoid-robotics/docs/week3-5-ros2/chapter-1-fundamentals',
                component: ComponentCreator('/physical-ai-humanoid-robotics/docs/week3-5-ros2/chapter-1-fundamentals', '4ce'),
                exact: true,
                sidebar: "introSidebar"
              },
              {
                path: '/physical-ai-humanoid-robotics/docs/week3-5-ros2/chapter-2-python-integration',
                component: ComponentCreator('/physical-ai-humanoid-robotics/docs/week3-5-ros2/chapter-2-python-integration', 'd28'),
                exact: true,
                sidebar: "introSidebar"
              },
              {
                path: '/physical-ai-humanoid-robotics/docs/week3-5-ros2/chapter-3-launch-files',
                component: ComponentCreator('/physical-ai-humanoid-robotics/docs/week3-5-ros2/chapter-3-launch-files', 'a6a'),
                exact: true,
                sidebar: "introSidebar"
              },
              {
                path: '/physical-ai-humanoid-robotics/docs/week3-5-ros2/chapter-3-urdf',
                component: ComponentCreator('/physical-ai-humanoid-robotics/docs/week3-5-ros2/chapter-3-urdf', '21e'),
                exact: true
              },
              {
                path: '/physical-ai-humanoid-robotics/docs/week3-5-ros2/resources/glossary',
                component: ComponentCreator('/physical-ai-humanoid-robotics/docs/week3-5-ros2/resources/glossary', '182'),
                exact: true
              },
              {
                path: '/physical-ai-humanoid-robotics/docs/week6-7-gazebo/',
                component: ComponentCreator('/physical-ai-humanoid-robotics/docs/week6-7-gazebo/', '3dc'),
                exact: true,
                sidebar: "introSidebar"
              },
              {
                path: '/physical-ai-humanoid-robotics/docs/week6-7-gazebo/chapter-1-gazebo-setup',
                component: ComponentCreator('/physical-ai-humanoid-robotics/docs/week6-7-gazebo/chapter-1-gazebo-setup', 'b1e'),
                exact: true,
                sidebar: "introSidebar"
              },
              {
                path: '/physical-ai-humanoid-robotics/docs/week6-7-gazebo/chapter-2-urdf-sdf-physics',
                component: ComponentCreator('/physical-ai-humanoid-robotics/docs/week6-7-gazebo/chapter-2-urdf-sdf-physics', 'c77'),
                exact: true,
                sidebar: "introSidebar"
              },
              {
                path: '/physical-ai-humanoid-robotics/docs/week6-7-gazebo/resources/glossary',
                component: ComponentCreator('/physical-ai-humanoid-robotics/docs/week6-7-gazebo/resources/glossary', 'b22'),
                exact: true
              },
              {
                path: '/physical-ai-humanoid-robotics/docs/week8-10-isaac/',
                component: ComponentCreator('/physical-ai-humanoid-robotics/docs/week8-10-isaac/', '3e4'),
                exact: true,
                sidebar: "introSidebar"
              },
              {
                path: '/physical-ai-humanoid-robotics/docs/week8-10-isaac/chapter-1-isaac-sdk-setup',
                component: ComponentCreator('/physical-ai-humanoid-robotics/docs/week8-10-isaac/chapter-1-isaac-sdk-setup', '52e'),
                exact: true,
                sidebar: "introSidebar"
              },
              {
                path: '/physical-ai-humanoid-robotics/docs/week8-10-isaac/chapter-2-ai-perception-manipulation',
                component: ComponentCreator('/physical-ai-humanoid-robotics/docs/week8-10-isaac/chapter-2-ai-perception-manipulation', '7b7'),
                exact: true,
                sidebar: "introSidebar"
              },
              {
                path: '/physical-ai-humanoid-robotics/docs/week8-10-isaac/chapter-3-reinforcement-learning-transfer',
                component: ComponentCreator('/physical-ai-humanoid-robotics/docs/week8-10-isaac/chapter-3-reinforcement-learning-transfer', 'b88'),
                exact: true,
                sidebar: "introSidebar"
              },
              {
                path: '/physical-ai-humanoid-robotics/docs/week8-10-isaac/diagrams/isaac-architecture',
                component: ComponentCreator('/physical-ai-humanoid-robotics/docs/week8-10-isaac/diagrams/isaac-architecture', '188'),
                exact: true
              },
              {
                path: '/physical-ai-humanoid-robotics/docs/week8-10-isaac/diagrams/isaac-architecture-overview',
                component: ComponentCreator('/physical-ai-humanoid-robotics/docs/week8-10-isaac/diagrams/isaac-architecture-overview', '6fb'),
                exact: true
              },
              {
                path: '/physical-ai-humanoid-robotics/docs/week8-10-isaac/diagrams/perception-pipeline',
                component: ComponentCreator('/physical-ai-humanoid-robotics/docs/week8-10-isaac/diagrams/perception-pipeline', '0e4'),
                exact: true
              },
              {
                path: '/physical-ai-humanoid-robotics/docs/week8-10-isaac/diagrams/rl-sim2real',
                component: ComponentCreator('/physical-ai-humanoid-robotics/docs/week8-10-isaac/diagrams/rl-sim2real', '4b3'),
                exact: true
              },
              {
                path: '/physical-ai-humanoid-robotics/docs/week8-10-isaac/resources/glossary',
                component: ComponentCreator('/physical-ai-humanoid-robotics/docs/week8-10-isaac/resources/glossary', '22e'),
                exact: true
              }
            ]
          }
        ]
      }
    ]
  },
  {
    path: '/physical-ai-humanoid-robotics/',
    component: ComponentCreator('/physical-ai-humanoid-robotics/', '96a'),
    exact: true
  },
  {
    path: '*',
    component: ComponentCreator('*'),
  },
];
